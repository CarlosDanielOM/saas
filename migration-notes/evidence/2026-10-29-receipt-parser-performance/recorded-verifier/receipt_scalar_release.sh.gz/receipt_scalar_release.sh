set -eu
export TZ=UTC
wave=/artifacts/receipt-parser-benchmark/attempt4
export AI_RECEIPT_BENCH_DIR="$wave/benchmark"
export AI_RECEIPT_BENCH_INPUT_SHA256=755bb61882c3d5a171fa21142ae799a00d86ea35f675b02e3155f467567648da
export AI_RECEIPT_BENCH_RUSTC_VERSION="$(rustc --version)"
export DIMA_AI_RECEIPT_NODE_BINARY=/artifacts/ai-credit-receipt/runtime-provenance/node
export DIMA_AI_RECEIPT_TYPESCRIPT_IMPLEMENTATION=/artifacts/ai-credit-receipt/runtime-provenance/typescript
export DIMA_AI_RECEIPT_TYPESCRIPT_PACKAGE=/artifacts/ai-credit-receipt/runtime-provenance/typescriptPackage
cargo test --release --locked --offline --no-default-features --features ai-usage-receipt-parser --test ai_usage_receipt_parser_benchmark prepared_receipt_parser_benchmark -- --ignored --exact --nocapture
sh /task-tools/receipt_lookup_profile4.sh
sh /task-tools/receipt_scalar_profile4.sh
sha256sum /target-cache/release/deps/libdima_rust-876f99c816a4cba7.rlib > /artifacts/receipt-parser-benchmark/lookup-diagnostic-attempt4/rlib.sha256
export DIMA_AI_USAGE_RECEIPT_PARSER_FIXTURE_DIR="$wave/parser"
export DIMA_AI_RECEIPT_NODE_ROOT=/artifacts/posthog-receipt/attempt1/node-provenance/root
export DIMA_AI_RECEIPT_NODE_BINARY=/artifacts/posthog-receipt/attempt1/node-provenance/node
find "$wave" -name '*.json' -type f -exec sha256sum {} \; | sort > "$wave/replay-before.sha256"
for zone in UTC America/New_York Europe/Berlin Australia/Lord_Howe Pacific/Apia; do
 TZ="$zone" cargo test --release --locked --offline --no-default-features --features ai-usage-receipt-parser,ai-usage-producer --test ai_usage_receipt_parser replay_actual_source_parser_and_bson -- --ignored --exact --nocapture
done
find "$wave" -name '*.json' -type f -exec sha256sum {} \; | sort > "$wave/replay-after.sha256"
cmp "$wave/replay-before.sha256" "$wave/replay-after.sha256"

