//! Small shared utilities.
//!
//! Keep this module limited to narrow, reusable pieces rather than a generic
//! framework or a parallel data-access layer. Service foundations mirror the
//! TypeScript helpers in `dimabot/src/utils`; each is behind its own feature.
//!
//! Enable individual consolidated helpers or `bot-utils` for all six. Provider
//! transports use the separate `twitch-client` and `polar-client` features.
//! These opt-in APIs do not register workers or install production adapters.
//!
//! ```
//! # #[cfg(all(feature = "keywords", feature = "eventsub"))] {
//! use dima_rust::utils::{eventsub, keywords};
//! let entries = [keywords::KeywordEntry {
//!     id: "greeting".into(), text: "hello".into(),
//!     match_mode: keywords::KeywordMatchMode::Anywhere,
//! }];
//! let index = keywords::compile_keyword_index(entries);
//! assert_eq!(keywords::match_keywords(&index, "Hello world").len(), 1);
//! let condition = eventsub::Condition::from([("broadcaster_user_id", "123")]);
//! assert_eq!(eventsub::subscription_key("channel.follow", "2", &condition),
//!     "channel.follow:2:{\"broadcaster_user_id\":\"123\"}");
//! # }
//! ```

#[cfg(any(
    feature = "js-strings",
    feature = "mongo",
    feature = "cron-supervisor",
    feature = "bot-utils",
    feature = "keywords",
    feature = "chat-events",
    feature = "ai-usage",
    feature = "eventsub",
    feature = "domain-events",
    feature = "chat-message",
    feature = "timer-policy",
    feature = "credit-policy",
    feature = "permissions",
    feature = "cron-queue",
    feature = "twitch-client",
    feature = "qdrant",
    feature = "ast-syntax",
    feature = "reward-body",
    feature = "tts-utilities",
    feature = "moderation-emote-spam",
    feature = "moderation-caps",
    feature = "js-unicode17",
    feature = "moderation-spam-categories",
    feature = "moderation-offenses"
))]
pub mod js_compat;

#[cfg(any(
    feature = "credit-policy",
    feature = "lossless-json",
    feature = "ast-evaluator",
    feature = "reward-body",
    feature = "domain-events",
    feature = "application-schemas",
    feature = "bits-rules",
    feature = "tts-utilities",
    feature = "moderation-emote-spam",
    feature = "moderation-caps",
    feature = "moderation-permit",
    feature = "moderation-offenses"
))]
pub mod json_number;

#[cfg(any(
    feature = "moderation-emote-spam",
    feature = "moderation-caps",
    feature = "moderation-blacklist",
    feature = "moderation-normalize",
    feature = "moderation-links",
    feature = "moderation-spam-categories",
    feature = "moderation-permit",
    feature = "moderation-offenses"
))]
pub mod moderation;

pub mod links;
pub mod tts_defaults;

#[cfg(any(
    feature = "tts-services",
    feature = "moderation-variations-provider",
    feature = "moderation-semantic"
))]
#[path = "ai/openrouter/app_attribution.util.rs"]
pub mod openrouter_attribution;

#[cfg(feature = "eventsub")]
pub mod eventsub_bits_config;

#[cfg(feature = "reward-body")]
#[path = "twitch_reward_body.util.rs"]
pub mod twitch_reward_body;

#[cfg(feature = "mongo")]
pub mod bson_compat;
#[cfg(all(feature = "mongo", feature = "tts-utilities"))]
pub mod bson_json;
#[cfg(feature = "mongo")]
pub mod utc_time;
#[cfg(any(feature = "mongo", feature = "cron-supervisor"))]
pub mod worker_process;

#[cfg(feature = "ast-blocks")]
#[path = "ast_blocks/index.rs"]
pub mod ast_blocks;
#[cfg(feature = "ast-evaluator")]
#[path = "ast_parser/evaluator.rs"]
pub mod ast_evaluator;
#[cfg(feature = "ast-syntax")]
#[path = "ast_parser/syntax.rs"]
pub mod ast_syntax;

#[cfg(feature = "ai-credit-projection")]
pub mod ai_credit_projection;

#[cfg(feature = "ai-credit-reader")]
pub mod ai_credit_reader;
#[cfg(feature = "ai-usage")]
pub mod ai_usage;
#[cfg(all(feature = "mongo", feature = "redis"))]
pub(crate) mod ai_usage_aggregate_policy;
#[cfg(feature = "ai-usage-ledger-backfill")]
pub mod ai_usage_ledger_backfill;
#[cfg(feature = "ai-usage-ledger-persistence")]
pub mod ai_usage_ledger_persistence;
#[cfg(feature = "ai-usage-ledger-queries")]
pub mod ai_usage_ledger_queries;
#[cfg(feature = "ai-usage-ledger-reads")]
pub mod ai_usage_ledger_reads;
#[cfg(feature = "ai-usage-lock")]
pub mod ai_usage_lock;
#[cfg(feature = "ai-usage-lossless")]
pub mod ai_usage_lossless;
#[cfg(feature = "ai-usage-producer")]
pub mod ai_usage_producer;
#[cfg(feature = "ai-usage-receipt-parser")]
pub mod ai_usage_receipt_parser;
#[cfg(feature = "ai-usage-retention")]
pub mod ai_usage_retention;
#[cfg(feature = "bson-js-json")]
pub mod bson_js_json;
#[cfg(feature = "chat-events")]
pub mod chat_events;
#[cfg(feature = "command-utils")]
pub mod command_cooldown;
#[cfg(feature = "domain-events")]
pub mod domain_events;
#[cfg(feature = "eventsub")]
pub mod eventsub;
#[cfg(feature = "js-date")]
pub mod js_date;
#[cfg(feature = "js-regexp-unicode")]
pub mod js_regexp_unicode;
#[cfg(any(
    feature = "js-strings",
    feature = "tts-utilities",
    feature = "permissions",
    feature = "moderation-caps",
    feature = "js-unicode17",
    feature = "moderation-spam-categories",
    feature = "moderation-offenses"
))]
pub mod js_string;
#[cfg(feature = "js-unicode17")]
pub mod js_unicode;
#[cfg(feature = "polar-cache-usage")]
pub mod polar_cache_usage;
#[cfg(feature = "js-regexp-unicode")]
#[rustfmt::skip]
mod js_regexp_unicode_data;
#[cfg(any(feature = "moderation-caps", feature = "js-regexp-unicode"))]
#[path = "moderation/caps_unicode_data.rs"]
#[rustfmt::skip]
mod js_unicode_categories;
#[cfg(feature = "js-unicode17")]
#[rustfmt::skip]
mod js_unicode_data;
#[cfg(feature = "keywords")]
pub mod keywords;
#[cfg(feature = "logger")]
pub mod logger;
#[cfg(feature = "lossless-json")]
pub mod lossless_json;
#[cfg(feature = "lossless-json")]
pub mod lossless_json_document;
#[cfg(feature = "lossless-json-view")]
pub mod lossless_json_view;
#[cfg(feature = "application-schemas")]
pub mod mongoose_date;
#[cfg(feature = "observability")]
pub mod observability;
#[cfg(feature = "plan-cache")]
pub mod plan_cache_fence;
#[cfg(feature = "polar-client")]
#[path = "polarsh.rs"]
pub mod polar;
#[cfg(feature = "redis-application-runtime")]
pub mod redis_application_runtime;
#[cfg(feature = "tts-utilities")]
pub mod tts;
#[cfg(any(feature = "credit-policy", feature = "tts-utilities"))]
#[path = "tts/usage.rs"]
pub mod tts_usage_pricing;
#[cfg(feature = "twitch-client")]
pub mod twitch;
#[cfg(feature = "twitch-emotes")]
pub mod twitch_emotes;

#[cfg(feature = "chat-message")]
pub mod chat_message;
#[cfg(feature = "credential-crypto")]
#[path = "crypto.rs"]
pub mod credential_crypto;
#[cfg(feature = "credit-policy")]
pub mod credit_policy;
#[cfg(feature = "cron-queue")]
#[path = "cron_jobs_queue.rs"]
pub mod cron_queue;
#[cfg(feature = "permissions")]
#[path = "permissions/index.rs"]
pub mod permissions;
#[cfg(feature = "timer-policy")]
pub mod timer_policy;
#[cfg(feature = "twitch-streamers")]
#[path = "../classes/twitch_streamers.class.rs"]
pub mod twitch_streamers;
#[cfg(feature = "twitch-tokens")]
#[path = "tokens.rs"]
pub mod twitch_tokens;

#[cfg(feature = "audio")]
pub mod audio;
#[cfg(feature = "http")]
pub mod cors;
#[cfg(feature = "email")]
#[path = "email/email.service.rs"]
pub mod email;
#[cfg(feature = "jwt")]
#[path = "email/email-activation-token.rs"]
pub mod jwt;
#[cfg(feature = "mongo")]
#[path = "databases/mongodb.database.rs"]
pub mod mongo;
#[cfg(feature = "otel")]
#[path = "opentelemetry_posthog.rs"]
pub mod otel;
#[cfg(feature = "posthog")]
#[path = "posthog_events.rs"]
pub mod posthog;
#[cfg(feature = "posthog-lossless")]
pub mod posthog_lossless;
#[cfg(feature = "posthog-tracking")]
pub mod posthog_tracking;
#[cfg(feature = "qdrant")]
#[path = "databases/qdrant.database.rs"]
pub mod qdrant;
#[cfg(feature = "re2-compat")]
pub mod re2_compat;
#[cfg(feature = "re2-native")]
pub mod re2_native;
#[cfg(feature = "re2-unicode")]
pub mod re2_unicode;
#[cfg(feature = "re2-unicode")]
#[rustfmt::skip]
mod re2_unicode_data;
#[cfg(feature = "re2-strings")]
pub mod re2_string;
#[cfg(feature = "redis")]
#[path = "databases/dragonfly.database.rs"]
pub mod redis;
#[cfg(feature = "s3")]
pub mod s3;
#[cfg(feature = "socketio")]
#[path = "../server/websocket.rs"]
pub mod socketio;

#[cfg(all(
    test,
    any(
        feature = "email",
        feature = "posthog",
        feature = "s3",
        feature = "otel",
        feature = "twitch-client",
        feature = "polar-client"
    )
))]
pub(crate) mod test_http;

/// Public PostHog project key hard-coded in `posthog_events.ts` and
/// `opentelemetry_posthog.ts`. Project keys are write-only ingestion tokens
/// meant to be embedded in clients; this is not a secret.
#[cfg(any(feature = "posthog", feature = "otel"))]
pub const POSTHOG_PROJECT_KEY: &str = "phc_ApcLd2XbNHavPCcyD9fFDVHxs7cCBPozWmSBFTqugfP";

/// Installs ring as rustls's process-wide crypto provider.
///
/// `email`, `posthog`, `s3`, and `otel` pull crates that compile rustls with
/// aws-lc-rs as well as ring, so rustls can no longer choose a default and
/// `rustls::ClientConfig::builder()` panics. Their own HTTP clients and the
/// MongoDB driver pass a provider explicitly; Redis TLS and any other code
/// using the default do not. Call this once at startup in binaries that enable
/// these features; [`redis::get_redis_client`] also calls it. It keeps ring,
/// the provider the database clients already use, and is a no-op when a
/// default is already installed.
#[cfg(any(
    feature = "email",
    feature = "posthog",
    feature = "s3",
    feature = "otel"
))]
pub fn install_default_tls_provider() {
    let _ = rustls::crypto::ring::default_provider().install_default();
}
