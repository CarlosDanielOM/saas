#![cfg(feature = "channel-fish-voice-favorites")]
use dima_rust::{
    schemas::channel_fish_voice_favorites::{self as favorites, FavoritesError},
    utils::{js_string::JsString, lossless_json::JsonValue},
};
use mongodb::bson::doc;

#[test]
fn alias_rules_and_utf16_boundaries() {
    let text = |s: &str| JsonValue::String(s.into());
    assert_eq!(
        favorites::normalize_favorite_alias(&text("\u{feff} Bill \u{2028}")).unwrap(),
        "bill"
    );
    for s in ["", "bill cypher", "_bill", "İ", &"a".repeat(41)] {
        let e = favorites::normalize_favorite_alias(&text(s)).unwrap_err();
        assert_eq!((e.status, e.code), (400, "invalid_alias"));
    }
    assert_eq!(
        favorites::normalize_favorite_alias(&text("RIAS_GREMORY"))
            .unwrap_err()
            .code,
        "alias_taken"
    );
    assert_eq!(
        favorites::normalize_favorite_alias(&JsonValue::Number(3.0))
            .unwrap_err()
            .code,
        "invalid_alias"
    );
    assert_eq!(
        favorites::make_favorite_alias(
            &JsString::from("Café Voice"),
            &[JsString::from("cafe_voice")]
        ),
        "cafe_voice_2"
    );
    assert_eq!(
        favorites::make_favorite_alias(&JsString::from_units(vec![97, 0xd800, 98]), &[]),
        "a_b"
    );
    assert_eq!(
        favorites::make_favorite_alias(&JsString::from("gojo"), &[]),
        "gojo_2"
    );
}

// I/O-only emulator: executes the operations built by the production core.
// It contains no retry loop, alias policy, capacity decision or rename policy.
#[derive(Default)]
struct ReplayState {
    calls: Vec<serde_json::Value>,
    settings: Vec<serde_json::Value>,
    events: Vec<&'static str>,
    stored: Option<serde_json::Value>,
    force_miss: bool,
    fail_cas: bool,
    fail_settings: bool,
    miss_change: Option<&'static str>,
}
#[derive(Default)]
struct ReplayRepo(std::sync::Mutex<ReplayState>);
impl favorites::FavoritesRepository for ReplayRepo {
    async fn execute(
        &self,
        op: favorites::FavoritesOperation,
    ) -> Result<Option<mongodb::bson::Document>, FavoritesError> {
        use favorites::FavoritesOperation as Op;
        use serde_json::{Value, json};
        let mut state = self.0.lock().unwrap();
        let val = |v: mongodb::bson::Document| serde_json::to_value(v).unwrap();
        let bson = |v: Value| mongodb::bson::serialize_to_document(&v).unwrap();
        match op {
            Op::Find(filter) => {
                state.events.push("findOne");
                state.calls.push(json!(["findOne", val(filter)]));
                Ok(state.stored.clone().map(bson))
            }
            Op::SettingsUpdate { filter, update } => {
                state.events.push("settingsUpdate");
                state.settings.push(json!([val(filter), val(update)]));
                if state.fail_settings {
                    return Err(FavoritesError::BsonBoundary("injected settings write"));
                }
                Ok(None)
            }
            Op::Update {
                filter,
                update,
                options,
            } => {
                let (filter, update, options) = (val(filter), val(update), options.map(val));
                state.events.push("updateOne");
                state
                    .calls
                    .push(json!(["updateOne", filter, update, options]));
                if let Some(insert) = update.get("$setOnInsert") {
                    if state.stored.is_none() {
                        state.stored = Some(insert.clone());
                    }
                } else if let Some(pull) = update.get("$pull") {
                    if let Some(stored) = &mut state.stored {
                        stored["favorites"]
                            .as_array_mut()
                            .unwrap()
                            .retain(|v| v["id"] != pull["favorites"]["id"]);
                    }
                }
                Ok(None)
            }
            Op::FindAndUpdate {
                filter,
                update,
                options,
            } => {
                let (filter, update, options) = (val(filter), val(update), val(options));
                state.events.push("findOneAndUpdate");
                state
                    .calls
                    .push(json!(["findOneAndUpdate", filter, update, options]));
                if state.fail_cas {
                    return Err(FavoritesError::BsonBoundary("injected uncertain write"));
                }
                if state.force_miss {
                    return Ok(None);
                }
                if let Some(mode) = state.miss_change.take() {
                    if let Some(stored) = &mut state.stored {
                        let rows = stored["favorites"].as_array_mut().unwrap();
                        if mode == "remove" {
                            rows.clear();
                        }
                        if mode == "same" {
                            rows[0]["alias"] = update["$set"]["favorites.$[target].alias"].clone();
                        }
                    }
                    return Ok(None);
                }
                let Some(stored) = &mut state.stored else {
                    return Ok(None);
                };
                let rows = stored["favorites"].as_array_mut().unwrap();
                if let Some(push) = update.get("$push") {
                    let row = &push["favorites"];
                    let limit = filter["$expr"]["$lt"][1].as_u64().unwrap() as usize;
                    let id = &filter["favorites.id"]["$ne"];
                    let alias = &filter["favorites.alias"]["$ne"];
                    if rows.len() >= limit
                        || rows.iter().any(|v| &v["id"] == id || &v["alias"] == alias)
                    {
                        return Ok(None);
                    }
                    rows.push(row.clone());
                } else {
                    let id = &filter["favorites.id"];
                    let alias = &filter["favorites.alias"]["$ne"];
                    if rows.iter().any(|v| &v["alias"] == alias) {
                        return Ok(None);
                    }
                    let Some(row) = rows.iter_mut().find(|v| &v["id"] == id) else {
                        return Ok(None);
                    };
                    row["alias"] = update["$set"]["favorites.$[target].alias"].clone();
                }
                Ok(Some(bson(stored.clone())))
            }
        }
    }
}
fn wire_favorite(value: favorites::Favorite) -> serde_json::Value {
    serde_json::json!({"id":value.id.to_utf8_lossy(),"name":value.name.to_utf8_lossy(),"alias":value.alias.to_utf8_lossy()})
}
fn wire_result(result: Result<serde_json::Value, FavoritesError>) -> serde_json::Value {
    match result {
        Ok(value) => serde_json::json!({"value":value}),
        Err(FavoritesError::Alias(e)) => {
            serde_json::json!({"error":{"status":e.status,"code":e.code,"message":e.message}})
        }
        Err(e) => serde_json::json!({"error":{"status":null,"code":null,"message":e.to_string()}}),
    }
}

#[path = "support/sha256.rs"]
mod digest;
#[tokio::test]
#[ignore = "requires separately generated external source oracle"]
async fn source_oracle_pure_and_protocol() {
    let path = std::path::PathBuf::from(std::env::var("FISH_FAVORITES_ORACLE").unwrap());
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .canonicalize()
        .unwrap();
    assert!(
        path.is_absolute()
            && std::fs::canonicalize(&path).unwrap() == path
            && !path.starts_with(root.parent().unwrap())
    );
    let bytes = std::fs::read(path).unwrap();
    assert_eq!(
        digest::sha256_hex(&bytes),
        std::env::var("FISH_FAVORITES_ORACLE_SHA256").unwrap()
    );
    let fixture: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
    assert_eq!(fixture["schema"], 1);
    assert_eq!(
        fixture["versions"],
        serde_json::json!({"node":"24.22.1","v8":"13.6.233.17-node.58","icu":"78.3","unicode":"17.0","typescript":"5.9.3"})
    );
    assert_eq!(
        fixture["nodeSha"],
        "569128f3066ac7be59b10b9a0adef708def642ee37cbf9d560a9bdb68f872108"
    );
    let files = [
        "src/schemas/channel_fish_voice_favorites.schema.ts",
        "src/schemas/channel_fish_voice_favorites.schema.test.ts",
        "src/schemas/channel_tts_settings.schema.ts",
        "src/server/services/tts/fish_tts.service.ts",
        "src/schemas/channel_fish_voice_favorites.schema.rs",
        "src/schemas/channel_tts_settings.schema.rs",
        "src/schemas/schema.rs",
        "src/server/services/tts/fish_tts.rs",
        "src/utils/js_string.rs",
        "src/utils/js_unicode.rs",
        "src/utils/js_unicode_data.rs",
        "src/utils/lossless_json.rs",
        "tests/channel_fish_voice_favorites.rs",
        "tests/fixtures/channel_fish_voice_favorites_reference.cjs",
        "Cargo.toml",
        "Cargo.lock",
        "rust-toolchain.toml",
        "package.json",
        "package-lock.json",
    ];
    assert_eq!(fixture["hashes"].as_object().unwrap().len(), files.len());
    let logical_settings = "src/schemas/channel_tts_settings.schema.ts";
    let active = root.join(logical_settings);
    let archived = root
        .parent()
        .unwrap()
        .join("archives/dimabot-typescript/2026-10-28")
        .join(logical_settings);
    assert_ne!(
        active.is_file(),
        archived.is_file(),
        "exactly one settings source or archive must exist"
    );
    assert_eq!(
        fixture["sourcePaths"].as_object().unwrap().len(),
        files.len()
    );
    for file in files {
        let resolved = if file == logical_settings && archived.is_file() {
            format!("../archives/dimabot-typescript/2026-10-28/{logical_settings}")
        } else {
            file.to_owned()
        };
        assert_eq!(fixture["sourcePaths"][file], resolved);
        assert_eq!(
            fixture["hashes"][file].as_str().unwrap(),
            digest::sha256_hex(&std::fs::read(root.join(resolved)).unwrap())
        );
    }
    assert_eq!(fixture["mongoose"], "8.24.2");
    assert_eq!(
        fixture["sdkHashes"]["settingsReference"].as_str().unwrap(),
        digest::sha256_hex(
            &std::fs::read(root.join("tests/fixtures/channel_tts_settings_reference.mjs")).unwrap()
        )
    );
    assert_eq!(
        fixture["metadata"],
        serde_json::json!({"model":"channel_fish_voice_favorites","collection":"channel_fish_voice_favorites","versionKey":"__v","timestamps":false,"indexes":[{"keys":{"channelID":1},"unique":true}],"subdocumentId":false,"paths":{"channelID":"String","favorites":"Array"},"favoritePaths":{"id":"String","name":"String","alias":"String"}})
    );
    let schema = favorites::schema();
    assert_eq!(schema.model, "channel_fish_voice_favorites");
    assert_eq!(schema.collection, "channel_fish_voice_favorites");
    assert!(schema.version_key && schema.timestamps.is_none());
    assert_eq!(schema.indexes.len(), 1);
    assert!(schema.indexes[0].unique);
    assert_eq!(schema.indexes[0].keys, doc! {"channelID":1});
    let expected_cases = serde_json::json!([
        {"input":{"channelID":"channel"},"output":{"channelID":"channel","favorites":[]},"error":null},
        {"input":{"channelID":42,"favorites":[{"id":123,"name":456,"alias":789}]},"output":{"channelID":"42","favorites":[{"id":"123","name":"456","alias":"789"}]},"error":null},
        {"input":{"channelID":"channel","favorites":[{"id":"x","name":"Voice","alias":"voice","extra":"ignored"}]},"output":{"channelID":"channel","favorites":[{"id":"x","name":"Voice","alias":"voice"}]},"error":null}
    ]);
    assert_eq!(fixture["schemaCases"], expected_cases);
    let inputs = [
        doc! {"channelID":"channel"},
        doc! {"channelID":42,"favorites":[{"id":123,"name":456,"alias":789}]},
        doc! {"channelID":"channel","favorites":[{"id":"x","name":"Voice","alias":"voice","extra":"ignored"}]},
    ];
    let outputs = [
        doc! {"channelID":"channel","favorites":[]},
        doc! {"channelID":"42","favorites":[{"id":"123","name":"456","alias":"789"}]},
        doc! {"channelID":"channel","favorites":[{"id":"x","name":"Voice","alias":"voice"}]},
    ];
    for (input, expected) in inputs.into_iter().zip(outputs) {
        let mut actual = schema
            .construct(&input, mongodb::bson::DateTime::from_millis(1900000000000))
            .unwrap();
        actual.remove("_id");
        assert_eq!(actual, expected);
    }
    let middleware = &fixture["settingsMiddleware"];
    assert_eq!(middleware["clock"], 1900000000000_i64);
    let ops = middleware["operations"].as_array().unwrap();
    assert_eq!(ops.len(), 1);
    assert_eq!(
        ops[0]["filter"],
        serde_json::json!({"channelID":"channel","voices.cloneDefault":"old"})
    );
    assert_eq!(ops[0]["update"]["$set"]["voices.cloneDefault"], "id");
    assert_eq!(
        ops[0]["update"]["$set"]["updatedAt"],
        "2030-03-17T17:46:40.000Z"
    );
    assert_eq!(
        ops[0]["update"]["$setOnInsert"]["createdAt"],
        "2030-03-17T17:46:40.000Z"
    );
    assert_eq!(fixture["max"], favorites::MAX_FISH_VOICE_FAVORITES);
    assert_eq!(
        fixture["exports"],
        serde_json::json!([
            "ChannelFishVoiceFavoritesSchema",
            "FavoriteAliasError",
            "MAX_FISH_VOICE_FAVORITES",
            "addFishVoiceFavorite",
            "getFishVoiceFavorites",
            "makeFavoriteAlias",
            "normalizeFavoriteAlias",
            "removeFishVoiceFavorite",
            "renameFishVoiceFavorite"
        ])
    );
    assert_eq!(
        fixture["typeDeclarations"],
        serde_json::json!([
            {"name":"FishVoiceFavorite","exported":true,"fields":[{"name":"id","type":"string"},{"name":"name","type":"string"},{"name":"alias","type":"string"}]},
            {"name":"ChannelFishVoiceFavorites","exported":false,"fields":[{"name":"channelID","type":"string"},{"name":"favorites","type":"FishVoiceFavorite[]"}]}
        ])
    );
    assert_eq!(unicode_normalization::UNICODE_VERSION, (18, 0, 0));
    let fish = fixture["fish"].as_object().unwrap();
    let native = dima_rust::tts_services::fish_tts::FISH_VOICES;
    assert_eq!(fish.len(), native.len());
    for (name, id) in native {
        assert_eq!(fish[*name], *id);
    }
    let units = |value: &serde_json::Value| {
        JsString::from_units(
            value
                .as_array()
                .unwrap()
                .iter()
                .map(|v| v.as_u64().unwrap() as u16)
                .collect(),
        )
    };
    for case in fixture["normalization"].as_array().unwrap() {
        let input = if case["input"].is_object() {
            JsonValue::String(units(&case["input"]["units"]))
        } else if let Some(n) = case["input"].as_f64() {
            JsonValue::Number(n)
        } else {
            JsonValue::Null
        };
        match favorites::normalize_favorite_alias(&input) {
            Ok(value) => assert_eq!(case["value"], value),
            Err(e) => assert_eq!(
                case["error"],
                serde_json::json!({"status":e.status,"code":e.code,"message":e.message})
            ),
        }
    }
    for case in fixture["aliases"].as_array().unwrap() {
        let used: Vec<_> = case["used"]
            .as_array()
            .unwrap()
            .iter()
            .map(|v| JsString::from(v.as_str().unwrap()))
            .collect();
        assert_eq!(
            case["alias"],
            favorites::make_favorite_alias(&units(&case["units"]), &used)
        );
    }
    // Exercise the same production operations against a recording I/O adapter.
    let cases = fixture["cases"].as_array().unwrap();
    assert_eq!(cases.len(), 12);
    let channel = JsString::from("channel");
    let id = JsString::from("id");
    for case in cases {
        let name = case["name"].as_str().unwrap();
        let repo = ReplayRepo::default();
        let result: Result<serde_json::Value, FavoritesError> = match name {
            "get_missing" => favorites::get_with(&repo, &channel)
                .await
                .map(|v| serde_json::json!(v.into_iter().map(wire_favorite).collect::<Vec<_>>())),
            "add" => favorites::add_with(&repo, &channel, &id, &JsString::from("Café Voice"))
                .await
                .map(wire_favorite),
            "existing" => {
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .unwrap();
                favorites::add_with(&repo, &channel, &id, &JsString::from("ignored"))
                    .await
                    .map(wire_favorite)
            }
            "remove" => {
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .unwrap();
                favorites::remove_with(&repo, &channel, &id).await.unwrap();
                favorites::get_with(&repo, &channel).await.map(|v| {
                    serde_json::json!(v.into_iter().map(wire_favorite).collect::<Vec<_>>())
                })
            }
            "rename" => {
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .unwrap();
                favorites::rename_with(&repo, &channel, &id, &JsonValue::String(" New ".into()))
                    .await
                    .map(wire_favorite)
            }
            "rename_missing" => {
                favorites::rename_with(&repo, &channel, &id, &JsonValue::String("new".into()))
                    .await
                    .map(wire_favorite)
            }
            "rename_taken" => {
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .unwrap();
                favorites::add_with(
                    &repo,
                    &channel,
                    &JsString::from("other"),
                    &JsString::from("Other"),
                )
                .await
                .unwrap();
                favorites::rename_with(&repo, &channel, &id, &JsonValue::String("other".into()))
                    .await
                    .map(wire_favorite)
            }
            "rename_fallthrough_remove"
            | "rename_fallthrough_same"
            | "rename_fallthrough_conflict" => {
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .unwrap();
                repo.0.lock().unwrap().miss_change = Some(match name {
                    "rename_fallthrough_remove" => "remove",
                    "rename_fallthrough_same" => "same",
                    _ => "conflict",
                });
                favorites::rename_with(&repo, &channel, &id, &JsonValue::String("new".into()))
                    .await
                    .map(wire_favorite)
            }
            "full" => {
                for i in 0..20 {
                    favorites::add_with(
                        &repo,
                        &channel,
                        &JsString::from(i.to_string()),
                        &JsString::from("Name"),
                    )
                    .await
                    .unwrap();
                }
                favorites::add_with(
                    &repo,
                    &channel,
                    &JsString::from("extra"),
                    &JsString::from("Name"),
                )
                .await
                .map(wire_favorite)
            }
            "conflict" => {
                repo.0.lock().unwrap().force_miss = true;
                favorites::add_with(&repo, &channel, &id, &JsString::from("Name"))
                    .await
                    .map(wire_favorite)
            }
            _ => panic!("unexpected scenario {name}"),
        };
        let state = repo.0.lock().unwrap();
        assert_eq!(
            *case,
            serde_json::json!({"name":name,"result":wire_result(result),"calls":state.calls,"settings":state.settings,"stored":state.stored}),
            "{name}"
        );
    }
}

#[tokio::test]
async fn actual_core_handles_cas_fallthrough_and_uncertain_errors() {
    let channel = JsString::from("channel");
    let id = JsString::from("id");
    let name = JsString::from("Name");
    let alias = JsonValue::String("new".into());
    for (mode, code) in [
        ("remove", "favorite_not_found"),
        ("same", "success"),
        ("conflict", "alias_taken"),
    ] {
        let repo = ReplayRepo::default();
        favorites::add_with(&repo, &channel, &id, &name)
            .await
            .unwrap();
        {
            let mut state = repo.0.lock().unwrap();
            state.calls.clear();
            state.settings.clear();
            state.events.clear();
            state.miss_change = Some(mode);
        }
        let result = favorites::rename_with(&repo, &channel, &id, &alias).await;
        if code == "success" {
            assert_eq!(result.unwrap().alias, JsString::from("new"));
        } else {
            assert!(matches!(result,Err(FavoritesError::Alias(e)) if e.code == code));
        }
        let state = repo.0.lock().unwrap();
        assert_eq!(state.calls.len(), 3);
        assert_eq!(state.calls[0][0], "findOne");
        assert_eq!(state.calls[1][0], "findOneAndUpdate");
        assert_eq!(state.calls[2][0], "findOne");
        assert_eq!(state.settings.len(), 1);
        assert_eq!(
            state.events,
            ["findOne", "settingsUpdate", "findOneAndUpdate", "findOne"]
        );
    }
    let repo = ReplayRepo::default();
    repo.0.lock().unwrap().force_miss = true;
    assert!(matches!(
        favorites::add_with(&repo, &channel, &id, &name).await,
        Err(FavoritesError::Conflict)
    ));
    {
        let state = repo.0.lock().unwrap();
        assert_eq!(
            state
                .calls
                .iter()
                .filter(|c| c[0] == "findOneAndUpdate")
                .count(),
            21
        );
    }
    let repo = ReplayRepo::default();
    repo.0.lock().unwrap().fail_cas = true;
    assert!(matches!(
        favorites::add_with(&repo, &channel, &id, &name).await,
        Err(FavoritesError::BsonBoundary("injected uncertain write"))
    ));
    {
        let state = repo.0.lock().unwrap();
        assert_eq!(state.calls.len(), 3);
        assert_eq!(state.calls[2][0], "findOneAndUpdate");
    }
    let repo = ReplayRepo::default();
    favorites::add_with(&repo, &channel, &id, &name)
        .await
        .unwrap();
    {
        let mut state = repo.0.lock().unwrap();
        state.calls.clear();
        state.settings.clear();
        state.events.clear();
        state.fail_cas = true;
    }
    assert!(matches!(
        favorites::rename_with(&repo, &channel, &id, &alias).await,
        Err(FavoritesError::BsonBoundary("injected uncertain write"))
    ));
    {
        let state = repo.0.lock().unwrap();
        assert_eq!(state.calls.len(), 2);
        assert_eq!(state.settings.len(), 1);
        assert_eq!(
            state.events,
            ["findOne", "settingsUpdate", "findOneAndUpdate"]
        );
    }
    let repo = ReplayRepo::default();
    favorites::add_with(&repo, &channel, &id, &name)
        .await
        .unwrap();
    {
        let mut state = repo.0.lock().unwrap();
        state.calls.clear();
        state.settings.clear();
        state.events.clear();
        state.fail_settings = true;
    }
    assert!(matches!(
        favorites::rename_with(&repo, &channel, &id, &alias).await,
        Err(FavoritesError::BsonBoundary("injected settings write"))
    ));
    {
        let state = repo.0.lock().unwrap();
        assert_eq!(state.calls.len(), 1);
        assert_eq!(state.settings.len(), 1);
    }
}

#[tokio::test]
#[ignore = "requires task-owned private keyword-mongo"]
async fn concrete_mongo_favorites_and_legacy_default() {
    use futures_util::FutureExt;
    use std::panic::AssertUnwindSafe;
    assert_eq!(
        std::env::var("DIMA_RUST_TEST_RESOURCE_OWNER").as_deref(),
        Ok("fish-voice-favorites")
    );
    assert_eq!(
        std::env::var("FISH_FAVORITES_MONGO_URI").as_deref(),
        Ok("mongodb://keyword-mongo:27017")
    );
    let namespace = std::env::var("FISH_FAVORITES_NAMESPACE").unwrap();
    let token = namespace
        .strip_prefix("fish-favorites-")
        .and_then(|s| s.strip_suffix(':'))
        .unwrap();
    assert!((6..=32).contains(&token.len()) && token.bytes().all(|b| b.is_ascii_alphanumeric()));
    let client = mongodb::Client::with_uri_str("mongodb://keyword-mongo:27017")
        .await
        .unwrap();
    let db = client.database(&format!("fish_favorites_{token}"));
    assert!(db.list_collection_names().await.unwrap().is_empty());
    let test = AssertUnwindSafe(async {
        favorites::install_indexes(&db).await.unwrap();
        let channel = JsString::from("channel"); let id = JsString::from("id");
        assert!(favorites::get_fish_voice_favorites(&db, &channel).await.unwrap().is_empty());
        let first = favorites::add_fish_voice_favorite(&db, &channel, &id, &JsString::from("Bill Cypher")).await.unwrap();
        assert_eq!(first.alias, JsString::from("bill_cypher"));
        let duplicate = favorites::schema().native_collection(&db).insert_one(doc! {"channelID":"channel","favorites":[]}).await;
        assert!(duplicate.is_err(), "explicit initializer must enforce channel uniqueness");
        assert_eq!(favorites::add_fish_voice_favorite(&db, &channel, &id, &JsString::from("ignored")).await.unwrap(), first);
        let settings = dima_rust::schemas::channel_tts_settings::schema().native_collection(&db);
        settings.insert_one(doc! {"channelID":"channel","voices":{"cloneDefault":"bill_cypher","en":"keep"}}).await.unwrap();
        let before_update = mongodb::bson::DateTime::now();
        let renamed = favorites::rename_fish_voice_favorite(&db, &channel, &id, &JsonValue::String(" Bill ".into())).await.unwrap();
        let after_update = mongodb::bson::DateTime::now();
        assert_eq!(renamed.alias, JsString::from("bill"));
        let stored = settings.find_one(doc! {"channelID":"channel"}).await.unwrap().unwrap();
        let voices = stored.get_document("voices").unwrap();
        assert_eq!(voices.get_str("cloneDefault").unwrap(), "id");
        assert_eq!(voices.get_str("en").unwrap(), "keep");
        let stamp = stored.get_datetime("updatedAt").unwrap().timestamp_millis();
        assert!(stamp >= before_update.timestamp_millis() && stamp <= after_update.timestamp_millis());
        assert!(!stored.contains_key("createdAt"));
        favorites::add_fish_voice_favorite(&db, &channel, &JsString::from("other"), &JsString::from("Other")).await.unwrap();
        assert!(matches!(favorites::rename_fish_voice_favorite(&db, &channel, &id, &JsonValue::String("other".into())).await, Err(FavoritesError::Alias(e)) if e.code == "alias_taken" && e.status == 409));
        assert!(matches!(favorites::rename_fish_voice_favorite(&db, &channel, &JsString::from("missing"), &JsonValue::String("new".into())).await, Err(FavoritesError::Alias(e)) if e.code == "favorite_not_found" && e.status == 404));
        for i in 2..20 { favorites::add_fish_voice_favorite(&db, &channel, &JsString::from(format!("id{i}")), &JsString::from("Voice")).await.unwrap(); }
        assert!(matches!(favorites::add_fish_voice_favorite(&db, &channel, &JsString::from("overflow"), &JsString::from("Voice")).await, Err(FavoritesError::Full)));
        favorites::remove_fish_voice_favorite(&db, &channel, &id).await.unwrap();
        assert_eq!(favorites::get_fish_voice_favorites(&db, &channel).await.unwrap().len(), 19);
        // The first settings migration precedes a later alias collision.
        let failure_channel = JsString::from("migration-failure");
        let left = JsString::from("left-id"); let right = JsString::from("right-id");
        favorites::add_fish_voice_favorite(&db, &failure_channel, &left, &JsString::from("Left")).await.unwrap();
        favorites::add_fish_voice_favorite(&db, &failure_channel, &right, &JsString::from("Right")).await.unwrap();
        settings.insert_one(doc! {"channelID":"migration-failure","voices":{"cloneDefault":"left"}}).await.unwrap();
        assert!(matches!(favorites::rename_fish_voice_favorite(&db, &failure_channel, &left, &JsonValue::String("right".into())).await, Err(FavoritesError::Alias(e)) if e.code == "alias_taken"));
        let settings_after = settings.find_one(doc! {"channelID":"migration-failure"}).await.unwrap().unwrap();
        assert_eq!(settings_after.get_document("voices").unwrap().get_str("cloneDefault").unwrap(), "left-id");
        assert_eq!(favorites::get_fish_voice_favorites(&db, &failure_channel).await.unwrap()[0].alias, JsString::from("left"));

        let race = JsString::from("race");
        // Seed the document to avoid conflating unique-index upsert races with CAS behavior.
        favorites::add_fish_voice_favorite(&db, &race, &JsString::from("seed"), &JsString::from("Seed")).await.unwrap();
        let same = JsString::from("same"); let same_name = JsString::from("Same");
        let (a, b) = tokio::join!(favorites::add_fish_voice_favorite(&db, &race, &same, &same_name), favorites::add_fish_voice_favorite(&db, &race, &same, &same_name));
        assert_eq!(a.unwrap(), b.unwrap());
        let one = JsString::from("one"); let two = JsString::from("two"); let shared_name = JsString::from("Shared Name");
        let (a, b) = tokio::join!(favorites::add_fish_voice_favorite(&db, &race, &one, &shared_name), favorites::add_fish_voice_favorite(&db, &race, &two, &shared_name));
        let (a, b) = (a.unwrap(), b.unwrap()); assert_ne!(a.alias, b.alias);
        let target_alias = JsonValue::String("contended".into());
        let (a, b) = tokio::join!(favorites::rename_fish_voice_favorite(&db, &race, &one, &target_alias), favorites::rename_fish_voice_favorite(&db, &race, &two, &target_alias));
        assert_eq!(usize::from(a.is_ok()) + usize::from(b.is_ok()), 1);
        assert!(matches!(a, Err(FavoritesError::Alias(ref e)) if e.code == "alias_taken") || matches!(b, Err(FavoritesError::Alias(ref e)) if e.code == "alias_taken"));
        let capacity = JsString::from("capacity-race");
        for i in 0..19 { favorites::add_fish_voice_favorite(&db, &capacity, &JsString::from(format!("n{i}")), &JsString::from("Voice")).await.unwrap(); }
        let a_id = JsString::from("a"); let b_id = JsString::from("b"); let voice = JsString::from("Voice");
        let (a, b) = tokio::join!(favorites::add_fish_voice_favorite(&db, &capacity, &a_id, &voice), favorites::add_fish_voice_favorite(&db, &capacity, &b_id, &voice));
        assert_eq!(usize::from(a.is_ok()) + usize::from(b.is_ok()), 1);
        assert!(matches!(a, Err(FavoritesError::Full)) || matches!(b, Err(FavoritesError::Full)));
        assert_eq!(favorites::get_fish_voice_favorites(&db, &capacity).await.unwrap().len(), 20);

        // BSON encodes lone surrogates as replacement characters. Reads compare
        // the decoded stored ID to the original JS string before issuing CAS.
        let replacement_channel = JsString::from("replacement");
        let lone_id = JsString::from_units(vec![0xd800]);
        let added = favorites::add_fish_voice_favorite(&db, &replacement_channel, &lone_id, &voice).await.unwrap();
        assert_eq!(added.id, lone_id);
        assert_eq!(favorites::get_fish_voice_favorites(&db, &replacement_channel).await.unwrap()[0].id, JsString::from("�"));
        assert!(matches!(favorites::add_fish_voice_favorite(&db, &replacement_channel, &lone_id, &voice).await, Err(FavoritesError::Conflict)));
        assert!(matches!(favorites::rename_fish_voice_favorite(&db, &replacement_channel, &lone_id, &JsonValue::String("new".into())).await, Err(FavoritesError::Alias(e)) if e.code == "favorite_not_found"));
        favorites::remove_fish_voice_favorite(&db, &replacement_channel, &lone_id).await.unwrap();
        assert!(favorites::get_fish_voice_favorites(&db, &replacement_channel).await.unwrap().is_empty());
        let coll = favorites::schema().native_collection(&db);
        coll.insert_one(doc! {"channelID":"malformed", "favorites": [42]}).await.unwrap();
        assert!(matches!(favorites::get_fish_voice_favorites(&db, &JsString::from("malformed")).await, Err(FavoritesError::BsonBoundary(_))));
    }).catch_unwind().await;
    db.drop().await.unwrap();
    if let Err(panic) = test {
        std::panic::resume_unwind(panic);
    }
}
